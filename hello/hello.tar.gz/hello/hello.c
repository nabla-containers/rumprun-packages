#include <stdio.h>
#include <unistd.h>
int
main()
{

printf("This is the Rumprun Hello World ...\n");
printf("... using the Solo5 framework ...\n");
printf("... in a Nabla container via runnc!\n");
sleep(2);
return 0;
}

